package com.example.mbmsmultisensors;

import android.graphics.Color;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class Brightness extends AppCompatActivity implements SensorEventListener {

    private SensorManager mSensorManager;
    private Sensor mLuz;
    private TextView messageTextView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_brightness);

        mSensorManager = (SensorManager) getSystemService(SENSOR_SERVICE);

        mLuz = mSensorManager.getDefaultSensor(Sensor.TYPE_LIGHT);

        messageTextView = findViewById(R.id.messageTextView);

        if (mLuz == null) {
            // Light sensor not available
            messageTextView.setText("Light sensor is not available");
            messageTextView.setVisibility(View.VISIBLE);
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        mSensorManager.registerListener(this, mLuz, SensorManager.SENSOR_DELAY_NORMAL);
    }

    @Override
    protected void onPause() {
        super.onPause();
        mSensorManager.unregisterListener(this);
    }

    @Override
    public void onAccuracyChanged(Sensor sensor, int accuracy) {
        // Not needed for this example
    }

    @Override
    public void onSensorChanged(SensorEvent event) {
        float lightValue = event.values[0];

        if (lightValue < 1) {
            // It's too dark
            getWindow().getDecorView().setBackgroundColor(Color.BLACK);
            messageTextView.setVisibility(View.VISIBLE);
        } else {
            // It's not too dark
            getWindow().getDecorView().setBackgroundColor(Color.WHITE);
            messageTextView.setVisibility(View.GONE);
        }
    }
}
