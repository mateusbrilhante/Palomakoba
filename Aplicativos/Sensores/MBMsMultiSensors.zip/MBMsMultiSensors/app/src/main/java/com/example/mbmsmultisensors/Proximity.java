package com.example.mbmsmultisensors;

import android.app.Activity;
import android.graphics.Color;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

public class Proximity extends Activity implements SensorEventListener {

    private SensorManager mSensorManager;
    private Sensor mProx;
    private TextView textView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_proximity);

        mSensorManager = (SensorManager) getSystemService(SENSOR_SERVICE);

        mProx = mSensorManager.getDefaultSensor(Sensor.TYPE_PROXIMITY);

        textView = findViewById(R.id.text_view);

        mSensorManager.registerListener(this, mProx, SensorManager.SENSOR_DELAY_FASTEST);
    }

    @Override
    public void onAccuracyChanged(Sensor sensor, int accuracy) {
        // Not needed for this example
    }

    @Override
    public void onSensorChanged(SensorEvent event) {
        if (event.sensor.getType() == Sensor.TYPE_PROXIMITY) {
            float distance = event.values[0];

            if (distance < mProx.getMaximumRange()) {
                // Too close, set screen to black and show the TextView
                getWindow().getDecorView().setBackgroundColor(Color.BLACK);
                textView.setVisibility(View.VISIBLE);
            } else {
                // Far enough, restore the original screen color and hide the TextView
                getWindow().getDecorView().setBackgroundColor(Color.WHITE);
                textView.setVisibility(View.INVISIBLE);
            }
        }
    }
}
