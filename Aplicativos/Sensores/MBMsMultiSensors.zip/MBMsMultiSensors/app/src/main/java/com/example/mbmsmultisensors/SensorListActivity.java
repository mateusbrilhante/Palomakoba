package com.example.mbmsmultisensors;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import androidx.appcompat.app.AppCompatActivity;

public class SensorListActivity extends AppCompatActivity {

    private ListView sensorListView;

    private String[] sensorNames = {
            "Accelerometer",
            "Brightness",
            "Proximity"
    };

    private Class<?>[] sensorActivities = {
            Accelerometer.class,
            Brightness.class,
            Proximity.class
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sensor_list);

        sensorListView = findViewById(R.id.sensorListView);

        ArrayAdapter<String> adapter = new ArrayAdapter<>(
                this,
                android.R.layout.simple_list_item_1,
                sensorNames
        );

        sensorListView.setAdapter(adapter);

        sensorListView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                if (position < sensorActivities.length) {
                    Intent intent = new Intent(SensorListActivity.this, sensorActivities[position]);
                    startActivity(intent);
                }
            }
        });
    }
}
